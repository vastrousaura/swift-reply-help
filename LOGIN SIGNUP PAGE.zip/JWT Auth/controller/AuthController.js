const User = require("../model/user");
const { createSecretToken } = require("../util/SecretToken");
const bcrypt = require("bcryptjs");


module.exports.Login = async (req, res, next) => {
    try {
      const { username, password } = req.body;
      if(!username || !password ){
        return res.json({message:'All fields are required'})
      }
      const user = await User.findOne({ username });
      if(!user){
        return res.json({message:'Incorrect password or username' }) 
      }
      const auth = await bcrypt.compare(password,user.password)
      if (!auth) {
        return res.json({message:'Incorrect password or username' }) 
      }
       const token = createSecretToken(user._id);
       res.cookie("token", token, {
         withCredentials: true,
         httpOnly: false,
       });
       res.redirect("/");
       next()
    } catch (error) {
      console.error(error);
    }
  }
module.exports.renderSignUpForm = (req,res) => {
    res.render("user/signUp.ejs");
}

module.exports.renderLoginForm = (req,res) => {
  res.render("user/login.ejs")
}

module.exports.Signup = async (req, res, next) => {
  try {
    const { email, password, username, createdAt } = req.body;
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.json({ message: "User already exists" });
    }
    const user = await User.create({ email, password, username, createdAt });
    const token = createSecretToken(user._id);
    res.cookie("jwt", token, {
      withCredentials: true,
      httpOnly: false,
    });
    res.redirect("/");
    next();
  } catch (error) {
    console.error(error);
  }
  // console.log(type);

};

module.exports.LogOut = (req,res) => {
  // console.log(req.cookies.token);
  res.cookie("token", " ", {maxAge : 1});
  res.redirect("/")
}