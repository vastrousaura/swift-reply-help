if (process.env.NODE_ENV != "production"){
    require("dotenv").config();
}
const express = require("express");
const app = express();
const ejsMate = require("ejs-mate");
const path = require("path");
const mongoose = require("mongoose");
const dbUrl = process.env.MONGO_URL;
const cloudinary = require('cloudinary').v2;
const cookieParser = require("cookie-parser");
const authRoute = require("./routes/AuthRoute");
const cors = require("cors");
cloudinary.config({
    cloud_name: process.env.CLOUD_NAME,
    api_key: process.env.CLOUD_API_KEY,
    api_secret: process.env.CLOUD_API_SECRET
});

main()
    .then(() => {
        console.log("connected to Db");
    })
    .catch((err) => {
        console.log(err);
    })

async function main() {
    await mongoose.connect(dbUrl);
}

app.set("view engine", "ejs");
app.set("views", path.join(__dirname,"views"));
app.engine("ejs", ejsMate);
app.use(express.static(path.join(__dirname, "/public")));
app.use(express.urlencoded({extended: true }));
app.use(
    cors({
      origin: ["http://localhost:8088"],
      methods: ["GET", "POST", "PUT", "DELETE"],
      credentials: true,
    })
);
app.use(cookieParser());
app.use((req,res,next) => {
    
    res.locals.user = req.cookies.token;
    // console.log(user);
    next();
});
app.use(express.json());

app.use("/", authRoute);


app.listen(8088, () => {
    console.log("started");
})
