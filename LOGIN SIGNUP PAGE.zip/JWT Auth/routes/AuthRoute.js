const { Signup, Login, renderSignUpForm, renderLoginForm, LogOut } = require('../controller/AuthController')
const router = require('express').Router()

router.route("/signup")
.get(renderSignUpForm)
.post(Signup)
router.route("/login")
.get(renderLoginForm)
.post( Login)
router.route("/logout")
.get(LogOut);

module.exports = router