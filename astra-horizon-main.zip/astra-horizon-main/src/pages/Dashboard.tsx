import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { 
  BarChart3, 
  MessageSquare, 
  Users, 
  Clock, 
  TrendingUp, 
  Bell,
  Settings,
  LogOut,
  LifeBuoy,
  Bot,
  X,
  Send
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";

const Dashboard = () => {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMessage, setChatMessage] = useState("");
  const [chatHistory, setChatHistory] = useState([
    { type: 'bot', message: 'Hello! I\'m here to help you with QuickDesk. What can I assist you with today?' }
  ]);
  const navigate = useNavigate();

  const stats = [
    {
      title: "Total Tickets",
      value: "1,234",
      change: "+12%",
      icon: MessageSquare,
      color: "text-primary",
      bgColor: "bg-primary-light",
    },
    {
      title: "Open Tickets",
      value: "87",
      change: "-5%",
      icon: Clock,
      color: "text-warning",
      bgColor: "bg-yellow-50",
    },
    {
      title: "Resolved Today",
      value: "45",
      change: "+23%",
      icon: TrendingUp,
      color: "text-success",
      bgColor: "bg-green-50",
    },
    {
      title: "Active Users",
      value: "156",
      change: "+8%",
      icon: Users,
      color: "text-secondary",
      bgColor: "bg-secondary-light",
    },
  ];

  const recentTickets = [
    {
      id: "#1234",
      title: "Login Issue - Cannot access dashboard",
      status: "Open",
      priority: "High",
      user: "John Doe",
      created: "2 hours ago",
      statusColor: "text-warning",
    },
    {
      id: "#1233",
      title: "Email notifications not working",
      status: "In Progress",
      priority: "Medium",
      user: "Jane Smith",
      created: "4 hours ago",
      statusColor: "text-primary",
    },
    {
      id: "#1232",
      title: "Feature request for bulk actions",
      status: "Resolved",
      priority: "Low",
      user: "Bob Wilson",
      created: "1 day ago",
      statusColor: "text-success",
    },
  ];

  const handleLogout = () => {
    navigate("/");
  };

  const getQuickDeskResponse = (message: string) => {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('what is quickdesk') || lowerMessage.includes('about quickdesk')) {
      return 'QuickDesk is a simple, powerful help desk solution that transforms customer support. We help teams resolve tickets faster and improve customer satisfaction.';
    }
    if (lowerMessage.includes('features') || lowerMessage.includes('what can it do')) {
      return 'QuickDesk offers smart ticket routing, real-time collaboration, powerful analytics, and seamless integrations. Our automated workflows help improve response times by up to 300%.';
    }
    if (lowerMessage.includes('pricing') || lowerMessage.includes('cost') || lowerMessage.includes('price')) {
      return 'We offer flexible pricing plans to suit teams of all sizes. Contact our sales team for detailed pricing information tailored to your needs.';
    }
    if (lowerMessage.includes('support') || lowerMessage.includes('help')) {
      return 'Our support team is available 24/7 to help you. You can reach us through this chat, email, or our knowledge base with detailed documentation.';
    }
    if (lowerMessage.includes('integrations') || lowerMessage.includes('integrate')) {
      return 'QuickDesk seamlessly integrates with popular tools like Slack, Jira, Salesforce, and more. Check our integrations page for the full list.';
    }
    if (lowerMessage.includes('workflow') || lowerMessage.includes('how it works')) {
      return 'Our workflow is simple: 1) Customers submit tickets, 2) Smart routing assigns to the right agent, 3) Teams collaborate in real-time, 4) Track resolution with analytics.';
    }
    if (lowerMessage.includes('analytics') || lowerMessage.includes('reports')) {
      return 'Our analytics dashboard provides insights on response times, resolution rates, customer satisfaction scores, and team performance metrics.';
    }
    return 'I\'m here to help! You can ask me about QuickDesk features, pricing, integrations, workflows, or any other questions about our platform.';
  };

  const handleSendMessage = () => {
    if (chatMessage.trim()) {
      const userMessage = chatMessage.trim();
      setChatHistory(prev => [...prev, { type: 'user', message: userMessage }]);
      setChatMessage("");
      
      // Simulate bot response after a short delay
      setTimeout(() => {
        const botResponse = getQuickDeskResponse(userMessage);
        setChatHistory(prev => [...prev, { type: 'bot', message: botResponse }]);
      }, 1000);
    }
  };

  return (
    <div className="min-h-screen bg-muted/30">
      {/* Header */}
      <header className="bg-white border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
                <LifeBuoy className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">QuickDesk Dashboard</h1>
                <p className="text-muted-foreground">Welcome back, Admin</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon">
                <Bell className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon">
                <Settings className="w-5 h-5" />
              </Button>
              <Button variant="ghost" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm font-medium">
                    {stat.title}
                  </p>
                  <div className="flex items-center space-x-2 mt-2">
                    <p className="text-3xl font-bold text-foreground">
                      {stat.value}
                    </p>
                    <span className={cn(
                      "text-sm font-medium",
                      stat.change.startsWith('+') ? "text-success" : "text-destructive"
                    )}>
                      {stat.change}
                    </span>
                  </div>
                </div>
                <div className={cn(
                  "w-12 h-12 rounded-lg flex items-center justify-center",
                  stat.bgColor
                )}>
                  <stat.icon className={cn("w-6 h-6", stat.color)} />
                </div>
              </div>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Tickets */}
          <div className="lg:col-span-2">
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold text-foreground">Recent Tickets</h3>
                <Button variant="outline" size="sm">
                  View All
                </Button>
              </div>
              <div className="space-y-4">
                {recentTickets.map((ticket, index) => (
                  <div key={index} className="p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <span className="text-sm font-medium text-muted-foreground">
                            {ticket.id}
                          </span>
                          <span className={cn("text-sm font-medium", ticket.statusColor)}>
                            {ticket.status}
                          </span>
                        </div>
                        <h4 className="text-foreground font-medium mb-1">
                          {ticket.title}
                        </h4>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <span>By {ticket.user}</span>
                          <span>{ticket.created}</span>
                          <span className={cn(
                            "px-2 py-1 rounded-full text-xs",
                            ticket.priority === "High" && "bg-red-100 text-red-700",
                            ticket.priority === "Medium" && "bg-yellow-100 text-yellow-700",
                            ticket.priority === "Low" && "bg-green-100 text-green-700"
                          )}>
                            {ticket.priority}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Quick Actions */}
          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="text-xl font-semibold text-foreground mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Create New Ticket
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Users className="w-4 h-4 mr-2" />
                  Manage Users
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  View Reports
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Settings className="w-4 h-4 mr-2" />
                  System Settings
                </Button>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-xl font-semibold text-foreground mb-4">Performance</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-muted-foreground">Resolution Rate</span>
                    <span className="font-medium">94%</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-gradient-primary h-2 rounded-full" style={{ width: '94%' }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-muted-foreground">Response Time</span>
                    <span className="font-medium">1.2h avg</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-gradient-to-r from-secondary to-accent h-2 rounded-full" style={{ width: '87%' }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-muted-foreground">Customer Satisfaction</span>
                    <span className="font-medium">4.8/5</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-gradient-to-r from-success to-success/80 h-2 rounded-full" style={{ width: '96%' }} />
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>

      {/* Chatbot */}
      <div className="fixed bottom-6 right-6 z-50">
        {!isChatOpen ? (
          <Button
            variant="cta"
            size="lg"
            onClick={() => setIsChatOpen(true)}
            className="rounded-full w-14 h-14 p-0 shadow-xl hover:shadow-glow"
          >
            <Bot className="w-6 h-6" />
          </Button>
        ) : (
          <Card className="w-80 h-96 flex flex-col shadow-xl">
            <div className="flex items-center justify-between p-4 border-b bg-gradient-primary text-white rounded-t-lg">
              <div className="flex items-center space-x-2">
                <Bot className="w-5 h-5" />
                <span className="font-semibold">QuickDesk Assistant</span>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsChatOpen(false)}
                className="text-white hover:bg-white/20"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            
            <div className="flex-1 p-4 space-y-4 overflow-y-auto">
              {chatHistory.map((chat, index) => (
                <div key={index} className={cn(
                  "rounded-lg p-3 max-w-[80%]",
                  chat.type === 'bot' 
                    ? "bg-muted mr-auto" 
                    : "bg-primary text-white ml-auto"
                )}>
                  <p className="text-sm">{chat.message}</p>
                </div>
              ))}
            </div>
            
            <div className="p-4 border-t">
              <div className="flex space-x-2">
                <input
                  type="text"
                  placeholder="Type your message..."
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  className="flex-1 px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
                <Button
                  size="icon"
                  onClick={handleSendMessage}
                  disabled={!chatMessage.trim()}
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default Dashboard;