import { 
  Users, 
  MessageSquare, 
  BarChart3, 
  Settings, 
  Bell, 
  Lock,
  Zap,
  Globe,
  HeadphonesIcon 
} from "lucide-react";
import { cn } from "@/lib/utils";

const FeaturesSection = () => {
  const features = [
    {
      icon: Users,
      title: "Multi-Role Support",
      description: "End users, support agents, and admins - each with tailored interfaces and permissions.",
      color: "text-primary",
      bgColor: "bg-primary-light",
    },
    {
      icon: MessageSquare,
      title: "Ticket Management",
      description: "Create, track, and resolve tickets with threaded conversations and status updates.",
      color: "text-secondary",
      bgColor: "bg-secondary-light",
    },
    {
      icon: BarChart3,
      title: "Analytics Dashboard",
      description: "Real-time insights into ticket volume, response times, and team performance.",
      color: "text-accent",
      bgColor: "bg-accent-light",
    },
    {
      icon: Settings,
      title: "Category Management",
      description: "Organize tickets by categories with automated routing and priority assignment.",
      color: "text-purple-500",
      bgColor: "bg-purple-50",
    },
    {
      icon: Bell,
      title: "Smart Notifications",
      description: "Email alerts for ticket creation, status changes, and important updates.",
      color: "text-orange-500",
      bgColor: "bg-orange-50",
    },
    {
      icon: Lock,
      title: "Secure & Reliable",
      description: "Enterprise-grade security with role-based access control and data protection.",
      color: "text-green-500",
      bgColor: "bg-green-50",
    },
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Optimized performance ensures quick response times and smooth user experience.",
      color: "text-yellow-500",
      bgColor: "bg-yellow-50",
    },
    {
      icon: Globe,
      title: "Cloud-Based",
      description: "Access your support system from anywhere with our reliable cloud infrastructure.",
      color: "text-blue-500",
      bgColor: "bg-blue-50",
    },
    {
      icon: HeadphonesIcon,
      title: "24/7 Support",
      description: "Our dedicated team is always here to help you get the most out of QuickDesk.",
      color: "text-pink-500",
      bgColor: "bg-pink-50",
    }
  ];

  return (
    <section id="support" className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Everything You Need for
            <span className="block bg-gradient-primary bg-clip-text text-transparent">
              Exceptional Support
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Comprehensive features designed to streamline your support workflow and delight your customers
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className={cn(
                "group relative p-8 rounded-2xl bg-gradient-card border border-border/50",
                "hover:shadow-elevated hover:scale-105 transition-all duration-500",
                "hover:border-primary/20"
              )}
            >
              {/* Background glow effect */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-primary opacity-0 group-hover:opacity-5 transition-opacity duration-500" />
              
              {/* Icon */}
              <div className={cn(
                "w-14 h-14 rounded-xl mb-6 flex items-center justify-center",
                "group-hover:scale-110 transition-transform duration-300",
                feature.bgColor
              )}>
                <feature.icon className={cn("w-7 h-7", feature.color)} />
              </div>

              {/* Content */}
              <div className="relative z-10">
                <h3 className="text-xl font-semibold text-foreground mb-3 group-hover:text-primary transition-colors">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </div>

              {/* Animated border */}
              <div className="absolute inset-0 rounded-2xl border-2 border-transparent group-hover:border-primary/20 transition-all duration-300" />
            </div>
          ))}
        </div>

        {/* User flow section */}
        <div className="mt-24">
          <div id="workflow" className="text-center mb-12">
            <h3 className="text-3xl font-bold text-foreground mb-4">
              Simple, Intuitive Workflow
            </h3>
            <p className="text-lg text-muted-foreground">
              From ticket creation to resolution - streamlined for efficiency
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                step: "01",
                title: "Create Ticket",
                description: "Users submit tickets with details, attachments, and category selection"
              },
              {
                step: "02",
                title: "Agent Assignment",
                description: "Smart routing assigns tickets to appropriate support agents automatically"
              },
              {
                step: "03",
                title: "Resolution & Feedback",
                description: "Agents resolve issues with threaded conversations and status updates"
              }
            ].map((step, index) => (
              <div key={index} className="text-center group">
                <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                  <span className="text-2xl font-bold text-white">{step.step}</span>
                </div>
                <h4 className="text-xl font-semibold text-foreground mb-3">
                  {step.title}
                </h4>
                <p className="text-muted-foreground">
                  {step.description}
                </p>
                {index < 2 && (
                  <div className="hidden md:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-primary to-secondary transform translate-x-8" />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;