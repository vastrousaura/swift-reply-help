import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Send, MessageSquare } from "lucide-react";

const ContactSection = () => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [message, setMessage] = useState("");
  const [buttonState, setButtonState] = useState<"contact" | "send" | "thankyou">("contact");

  const handleContactClick = () => {
    if (!isExpanded) {
      setIsExpanded(true);
      setButtonState("send");
    }
  };

  const handleSend = async () => {
    if (!message.trim()) return;
    
    setButtonState("thankyou");
    
    // Here you would integrate with Supabase to send the email
    console.log("Message to send:", message);
    console.log("To: bhardwajeklavya2000003@gmail.com");
    
    setTimeout(() => {
      setButtonState("contact");
      setIsExpanded(false);
      setMessage("");
    }, 2000);
  };

  const getButtonContent = () => {
    switch (buttonState) {
      case "contact":
        return (
          <>
            <MessageSquare className="w-5 h-5" />
            Contact Us
          </>
        );
      case "send":
        return (
          <>
            <Send className="w-5 h-5" />
            Send
          </>
        );
      case "thankyou":
        return "Thank You!";
    }
  };

  return (
    <section id="contact" className="py-20 bg-gradient-to-b from-background to-muted/30">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Tell Us What You Think
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            We value your feedback and would love to hear from you. Share your thoughts, suggestions, or questions with us.
          </p>
        </div>

        <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 border border-white/20 shadow-xl max-w-2xl mx-auto">
          <div className="space-y-6">
            <div className={`transition-all duration-500 ease-in-out ${
              isExpanded ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0 overflow-hidden'
            }`}>
              <Textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Share your thoughts with us..."
                className="min-h-[150px] border-2 border-primary/20 focus:border-primary/50 rounded-xl resize-none bg-white/50 backdrop-blur-sm"
              />
            </div>
            
            <div className={`flex ${isExpanded ? 'justify-end' : 'justify-center'} transition-all duration-300`}>
              <Button
                variant={buttonState === "thankyou" ? "secondary" : "default"}
                size="lg"
                onClick={buttonState === "contact" ? handleContactClick : handleSend}
                disabled={buttonState === "thankyou" || (buttonState === "send" && !message.trim())}
                className="px-8 py-4 text-lg transition-all duration-300"
              >
                {getButtonContent()}
              </Button>
            </div>
          </div>
        </div>

        <div className="text-center mt-8">
          <p className="text-sm text-muted-foreground">
            We typically respond within 24 hours
          </p>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;