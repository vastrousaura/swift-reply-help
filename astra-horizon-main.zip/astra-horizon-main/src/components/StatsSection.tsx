import { TrendingUp, Users, Clock, CheckCircle } from "lucide-react";
import { cn } from "@/lib/utils";

const StatsSection = () => {
  const stats = [
    {
      icon: Users,
      value: "50K+",
      label: "Happy Customers",
      description: "Trust QuickDesk for their support needs",
      color: "text-primary",
      bgColor: "bg-primary-light",
    },
    {
      icon: CheckCircle,
      value: "99.9%",
      label: "Resolution Rate",
      description: "Successfully resolved tickets",
      color: "text-success",
      bgColor: "bg-green-50",
    },
    {
      icon: Clock,
      value: "< 2hrs",
      label: "Average Response",
      description: "Lightning fast support response",
      color: "text-secondary",
      bgColor: "bg-secondary-light",
    },
    {
      icon: TrendingUp,
      value: "150%",
      label: "Efficiency Boost",
      description: "Improved team productivity",
      color: "text-accent",
      bgColor: "bg-accent-light",
    },
  ];

  return (
    <section id="stats" className="py-20 bg-gradient-to-br from-muted/30 to-background">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Trusted by Teams Worldwide
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Join thousands of companies that have transformed their customer support with QuickDesk
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className={cn(
                "group relative p-8 rounded-2xl bg-gradient-card border border-border/50",
                "hover:shadow-elevated hover:scale-105 transition-all duration-500",
                "hover:border-primary/20"
              )}
            >
              {/* Background Glow */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-primary opacity-0 group-hover:opacity-5 transition-opacity duration-500" />
              
              {/* Icon */}
              <div className={cn(
                "w-16 h-16 rounded-xl mb-6 flex items-center justify-center",
                "group-hover:scale-110 transition-transform duration-300",
                stat.bgColor
              )}>
                <stat.icon className={cn("w-8 h-8", stat.color)} />
              </div>

              {/* Content */}
              <div className="relative z-10">
                <div className="text-4xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                  {stat.value}
                </div>
                <div className="text-lg font-semibold text-foreground mb-2">
                  {stat.label}
                </div>
                <div className="text-muted-foreground">
                  {stat.description}
                </div>
              </div>

              {/* Animated border */}
              <div className="absolute inset-0 rounded-2xl border-2 border-transparent group-hover:border-primary/20 transition-all duration-300" />
            </div>
          ))}
        </div>

        {/* Additional testimonial */}
        <div className="mt-16 text-center">
          <div className="bg-white rounded-2xl p-8 shadow-lg max-w-4xl mx-auto border border-border/50">
            <p className="text-xl text-muted-foreground italic mb-6">
              "QuickDesk transformed our customer support completely. Response times improved by 300% and our team efficiency increased dramatically."
            </p>
            <div className="flex items-center justify-center space-x-4">
              <div className="w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center">
                <span className="text-white font-bold">EB</span>
              </div>
              <div>
                <div className="font-semibold text-foreground">Eklavya Bhardwaj</div>
                <div className="text-muted-foreground">CTO, Quick Desk</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default StatsSection;